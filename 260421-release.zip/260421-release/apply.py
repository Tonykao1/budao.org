#!/usr/bin/env python3
"""Apply the album to a clean local BUDAO checkout; never commits or pushes."""
import argparse, hashlib, importlib.util, json, shutil, subprocess, sys
from pathlib import Path
from PIL import Image
HERE=Path(__file__).resolve().parent
p=argparse.ArgumentParser(); p.add_argument('repo',type=Path); args=p.parse_args(); root=args.repo.resolve()
def git(*a): return subprocess.check_output(['git','-C',str(root),*a],text=True).strip()
assert git('rev-parse','--show-toplevel')==str(root), 'Specify repository root'
assert 'tonykao1/budao.org' in git('remote','get-url','origin').lower().replace(':','/'), 'Wrong origin'
assert not git('status','--porcelain'), 'Working tree must be clean'
archive_path=root/'data/campfire-archive.json'; quality_path=root/'data/campfire-hero-quality.json'; test_path=root/'test/campfire-page.test.js'
archive=json.loads(archive_path.read_text()); quality=json.loads(quality_path.read_text()); album=json.loads((HERE/'album.json').read_text()); manifest=json.loads((HERE/'manifest.json').read_text())
assert all(a['id']!=album['id'] for a in archive['albums']), 'Album already exists; stop to avoid overwriting'
assert len(manifest)==len(album['photos'])==6
idx=next((i for i,a in enumerate(archive['albums']) if a['date']<album['date']),len(archive['albums']))
assert any(a['id']=='260420' for a in archive['albums']), 'Expected neighboring historical album missing'
for m,photo in zip(manifest,album['photos']):
    assert m['src']==photo['src']; path=HERE/m['src'].lstrip('/'); assert hashlib.sha256(path.read_bytes()).hexdigest()==m['sha256']; assert not (root/m['src'].lstrip('/')).exists()
    with Image.open(path) as im: im.load(); assert im.format=='WEBP' and im.size==(m['width'],m['height']) and not im.getexif()
# Load the repository's own watermark implementation; retain exact existing brand and scoring rules.
spec=importlib.util.spec_from_file_location('campfire_watermark',root/'scripts/campfire-watermark.py'); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
svg=(root/'assets/budao-footprint-watermark.svg').read_bytes()
for m in manifest:
    rel=m['src'].removeprefix('/campfire-photos/'); src=root/m['src'].lstrip('/'); src.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(HERE/m['src'].lstrip('/'),src)
    dest=root/'campfire-watermarked'/rel; mod.make_copy(src,dest,svg); quality['scores'][m['src']]=mod.hero_quality_score(src)
archive['albums'].insert(idx,album); quality['scores']=dict(sorted(quality['scores'].items()))
for path,value in [(archive_path,archive),(quality_path,quality)]: path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
with test_path.open('a',encoding='utf-8') as f: f.write((HERE/'test-append.js').read_text())
subprocess.run(['node','--test','test/campfire-page.test.js'],cwd=root,check=True)
print('Local album test passed. Review git diff and commit/push only when approved.'); print(git('status','--short'))

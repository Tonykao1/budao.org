
test("神堂峪备线6张实拍完整保留，按日期独立归档", () => {
  const album = archive.albums.find(a => a.id === "260421");
  const quality = JSON.parse(read("data/campfire-hero-quality.json"));
  assert.ok(album && album.published);
  assert.equal(album.title, "神堂峪备线");
  assert.equal(album.date, "2026-04-21");
  assert.equal(album.photos.length, 6);
  assert.deepEqual(album.photos.map(p=>p.frameRatio), ["9/16","9/16","9/16","16/9","9/16","9/16"]);
  assert.ok(archive.albums.indexOf(album) < archive.albums.findIndex(a=>a.id==="260420"));
  for (const [j,p] of album.photos.entries()) {
    assert.equal(p.src, "/campfire-photos/260421/260421-"+String(j+1).padStart(2,"0")+".webp");
    assert.ok(exists(p.src));
    const bytes=fs.readFileSync(path.join(root,p.src.slice(1)));
    assert.equal(bytes.toString("ascii",0,4),"RIFF");
    assert.equal(bytes.toString("ascii",8,12),"WEBP");
    assert.equal(p.approved,true);
    assert.equal(p.frameMode,"uncropped");
    assert.ok(p.alt && p.caption);
    assert.ok(Number.isInteger(quality.scores[p.src]));
    assert.ok(exists(p.src.replace("/campfire-photos/","/campfire-watermarked/")));
  }
});

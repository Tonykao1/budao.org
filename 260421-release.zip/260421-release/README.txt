260421·神堂峪备线 — 待发布包（未提交、未部署）
6张 WebP，保留原始尺寸与构图，清除 EXIF。album.json 为待合入的独立记录；manifest.json 为校验清单。
在已同步的干净 budao.org Git 仓库上执行（需 Python、Pillow、CairoSVG、Node.js）：
  python3 /实际解压目录/260421-release/apply.py /实际仓库路径/budao.org
脚本会校验仓库及文件、按日期插入相册、调用仓库原有水印与质量评分函数、补充测试并运行相册测试。不会提交、推送或部署。完整仓库测试尚未在本会话环境运行。若测试失败，停止并检查 git diff；不要推送。
验收通过后，在仓库中审核变更并提交、推送，确认 Vercel 生产部署 READY 和正式域名上六张照片及水印均可加载。注意发布日期如有变化请相应更新 publishedOn。

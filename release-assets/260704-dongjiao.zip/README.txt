步道·营火之地｜260704·东郊湿地公园

包含3张已优化WebP原图和一份待发布相册记录。
将 campfire-photos/260704 内3个文件放入仓库同名目录。
将 album-260704.json 中对象并入 data/campfire-archive.json 的 albums，核对照片公众展示授权后设置 published: true 并填入实际 publishedOn 日期。
现有 .github/workflows/campfire-watermark.yml 将在合并至 main 后自动为图片生成水印展示版。
不要修改其他相册目录。
